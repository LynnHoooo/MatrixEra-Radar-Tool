//
//  OTAFile.m
//  1755OTA
//
//  Created by  on 2018/9/4.
//  Copyright © 2018年 杨赛. All rights reserved.
//

#import "OTAFile.h"

@implementation OTAFile
{
    
}
@synthesize  controller,selectedPeripheral,centralManager,selectedFileUrl,selectedFirmware,selectedFileDataUrl;


+(OTAFile *)sharedManager
{
    static OTAFile *sharedAccountManagerInstance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        sharedAccountManagerInstance = [[self alloc] init];
    });
    return sharedAccountManagerInstance;
}

-(void)SetBleCenter:(CBCentralManager*)center Peripheral:(CBPeripheral*)peripheral
{
    selectedPeripheral = peripheral;
    centralManager = center;
}

-(void)onFileSelected:(NSURL *)fileURL
{
   
    
    
    
    selectedFileUrl = fileURL;
    selectedFileDataUrl = [NSURL fileURLWithPath:@"file:///var/containers/Bundle/Application/E4F79CED-6495-49B8-95DA-54B0F4E68CC0/nRF%20Toolbox.app/firmwares/X9ET_4.3.0.dat"];
    selectedFirmware = nil;
    NSString *fileNameComponent = fileURL.lastPathComponent;
    NSString *extension = [[fileNameComponent pathExtension] lowercaseString];
    if ([extension isEqualToString:@"zip"])
    {
        selectedFirmware = [[DFUFirmware alloc] initWithUrlToZipFile:fileURL];
        
        if (selectedFirmware && selectedFirmware.fileName)
        {
            
            NSData *content = [[NSData alloc] initWithContentsOfURL:fileURL];
            NSLog(@"%@", [NSString stringWithFormat:@"%lu bytes", (long) content.length]);
            
        }
        else
        {
            selectedFirmware = nil;
            selectedFileUrl = nil;
        }
        
    }
    else
    {
        
    }
     
}

-(void)startOTA
{
    DFUServiceInitiator *initiator = [[DFUServiceInitiator alloc] initWithCentralManager: centralManager target:selectedPeripheral];
    /** 旧方法 */
    //[initiator withFirmwareFile:selectedFirmware];
    /** 新方法 */
    initiator = [initiator withFirmware:selectedFirmware];
     initiator.forceDfu = YES; // default NO
 
    /*
    initiator.forceDfu = [[[NSUserDefaults standardUserDefaults] valueForKey:@"dfu_force_dfu"] boolValue];
    initiator.packetReceiptNotificationParameter = [[[NSUserDefaults standardUserDefaults] valueForKey:@"dfu_number_of_packets"] intValue];
     
     */
    
    initiator.logger = self;
    initiator.delegate = self;
    initiator.progressDelegate = self;
//    initiator.enableUnsafeExperimentalButtonlessServiceInSecureDfu = YES;
    // initiator.peripheralSelector = ... // the default selector is used
    
    

    controller = [initiator start];
}

#pragma mark -DFUProgressDelegate
- (void)dfuProgressDidChangeFor:(NSInteger)part outOf:(NSInteger)totalParts to:(NSInteger)progress currentSpeedBytesPerSecond:(double)currentSpeedBytesPerSecond avgSpeedBytesPerSecond:(double)avgSpeedBytesPerSecond
{
    self.callBackBlock(progress);
}
#pragma mark -DFUProgressDelegate
- (void)dfuStateDidChangeTo:(enum DFUState)state
{
  
    NSLog(@"DFUState = %d",state);
}

-(void)dfuError:(enum DFUError)error didOccurWithMessage:(NSString * _Nonnull)message
{
    [self.delegate MyOTAStatusDelegate:message centralManager:centralManager];
    
    
}
#pragma mark -LoggerDelegate
- (void)logWith:(enum LogLevel)level message:(NSString * _Nonnull)message
{
    
    
   
    if([message isEqualToString:@"Device disconnected unexpectedly"]||[message isEqualToString:@"Disconnected by the remote device"])
    {
         [self.delegate MyOTAStatusDelegate:message centralManager:centralManager];
    }
}

@end
