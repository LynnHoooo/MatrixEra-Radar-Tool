//
//  SoureOTAFile.h
//  1755OTA
//
//  Created by  on 2018/9/5.
//  Copyright © 2018年 杨赛. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol SourceProgressDelegate
-(void)MySourceProgress:(float)progress;
@end
@interface SoureOTAFile : NSObject
{
    
    NSString * strMyMD5;
    NSMutableArray * arrayBlockCRC;//每个块的CRC
    int  ableLength;//可以发送数据的长度
    NSMutableArray * arrayTemp;//总的数据
    unsigned int dataLength;
    unsigned int CRC;
    unsigned  char * p;
    int totalPackage;
}
@property (nonatomic,retain) id<SourceProgressDelegate>delegate;
@property (nonatomic,retain) NSMutableArray * arraySendCRCCheck;
@property (nonatomic,retain)  NSMutableArray * arrayReceiveCRCCheck;
@property (nonatomic,retain)  NSMutableArray * arrayDetailTemp;
@property int CurrentBlock;
+(SoureOTAFile *)sharedManager;
-(void)SetLenghtUnit:(int)lenght;
-(void)GetStrMD5:(NSString*)strMD5;
-(void)readDataFromFilePath:(NSString*)strFile;
-(void)FirstStepWithType:(int)type;
//检查这块需不需要升级
-(void)check1024CRCWithLocath:(int)location;
// 需要升级发送数据
-(void)sendDataWithLocation:(int)location;
//发送最后一条数据
-(void)sendLastData;
//升级成功 清除数组
-(void)CleadData;
//擦除资源文件
-(void)EraseResourceFiles;
@end
