//
//  BleDefines.h
//  Created by Tony on 10/22/2012.
//  Copyright (c) 2012 Jess Tech. All rights reserved.
//
#ifndef BleDefines_h
#define BleDefines_h



//Service
#define ISSC_SERVICE_UUID                          @"FFF0"
//接收
#define ISSC_CHAR_RX_UUID                          @"FFF7"
//发送
#define ISSC_CHAR_TX_UUID                          @"FFF6"



#endif












