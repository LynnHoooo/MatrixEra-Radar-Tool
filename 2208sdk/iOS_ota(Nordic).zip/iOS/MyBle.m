//
//  MyBle.m
//  MyBle
//
//  Created by  on 16/5/25.
//  Copyright © 2016年 杨赛. All rights reserved.
//

#import "MyBle.h"
#import "MyFileView.h"
BOOL IsRepeatConnect;
BOOL IsOTA;
@implementation MyBle
{
    
}

@synthesize CM,activePeripheral,manager,_subscribedCentrals,mycharacteristic,isDfuTarg,strIdentifier;




+(MyBle *)sharedManager
{
    static MyBle *sharedAccountManagerInstance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        sharedAccountManagerInstance = [[self alloc] init];
    });
    return sharedAccountManagerInstance;
}

//设置为主设备
- (void)CentralManagerSetUp{
    
    /*Central Manager Initialization Options 对应的有两项：
     CBCentralManagerOptionShowPowerAlertKey
     布尔值，表示的是在central manager初始化时，如果当前蓝牙没打开，是否弹出alert框。
     CBCentralManagerOptionRestoreIdentifierKey
     CBCentralManagerOptionRestoreIdentifierKey，字符串，一个唯一的标示符，用来蓝牙的恢复连接的。在后台的长连接中可能会用到。
     就是说，如果蓝牙程序进入后台，程序会被挂起，可能由于memory pressure，程序被系统kill了，那么代理方法就不会执行了。这时候可以使用State Preservation & Restoration，这样程序会重新加载进入后台。*/
    
    /* NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:
     [NSNumber numberWithBool:YES],CBCentralManagerOptionShowPowerAlertKey,
     @"zStrapRestoreIdentifier",CBCentralManagerOptionRestoreIdentifierKey,
     nil];*/
    
    self.CM = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
    // 默认是过滤-70一下信号强度的设备
    self.BleRSSIValue = -70;
}
//设置为从设备
-(void)PeripheralManagerSetUp
{
//    self.manager = [[CBPeripheralManager alloc]initWithDelegate:self queue:nil];
    
}

-(void)addMyService
{
    /*
    if(self.manager.state==5)
    {
        CBUUID *characteristicUUID = [CBUUID UUIDWithString:@"0x0001"];
        mycharacteristic = [[CBMutableCharacteristic alloc] initWithType:characteristicUUID
                                                              properties:CBCharacteristicPropertyNotify
                                                                   value:nil
                                                             permissions:CBAttributePermissionsWriteable];
        CBUUID *serviceUUID = [CBUUID UUIDWithString:@"0x1234"];
        CBMutableService * service = [[CBMutableService alloc] initWithType:serviceUUID primary:YES];
        [service setCharacteristics:@[mycharacteristic]];
        [self.manager addService:service];
    }
    
     
     */
    
    //    //characteristics字段描述
    //    CBUUID *CBUUIDCharacteristicUserDescriptionStringUUID = [CBUUID UUIDWithString:CBUUIDCharacteristicUserDescriptionString];
    //    /*
    //     可以通知的Characteristic
    //     properties：CBCharacteristicPropertyNotify
    //     permissions CBAttributePermissionsReadable
    //     */
    //    CBMutableCharacteristic *notiyCharacteristic = [[CBMutableCharacteristic alloc]initWithType:[CBUUID UUIDWithString:@"0x0123"] properties:CBCharacteristicPropertyNotify value:nil permissions:CBAttributePermissionsReadable];
    //    /*
    //     可读写的characteristics
    //     properties：CBCharacteristicPropertyWrite | CBCharacteristicPropertyRead
    //     permissions CBAttributePermissionsReadable | CBAttributePermissionsWriteable
    //     */
    //    CBMutableCharacteristic *readwriteCharacteristic = [[CBMutableCharacteristic alloc]initWithType:[CBUUID UUIDWithString:@"0x1234"] properties:CBCharacteristicPropertyWrite | CBCharacteristicPropertyRead value:nil permissions:CBAttributePermissionsReadable | CBAttributePermissionsWriteable];
    //    //设置description
    //    CBMutableDescriptor *readwriteCharacteristicDescription1 = [[CBMutableDescriptor alloc]initWithType: CBUUIDCharacteristicUserDescriptionStringUUID value:@"name"];
    //    [readwriteCharacteristic setDescriptors:@[readwriteCharacteristicDescription1]];
    //    /*
    //     只读的Characteristic
    //     properties：CBCharacteristicPropertyRead
    //     permissions CBAttributePermissionsReadable
    //     */
    //    CBMutableCharacteristic *readCharacteristic = [[CBMutableCharacteristic alloc]initWithType:[CBUUID UUIDWithString:@"0x2345"] properties:CBCharacteristicPropertyRead value:nil permissions:CBAttributePermissionsReadable];
    //    //service1初始化并加入两个characteristics
    //    CBMutableService *service1 = [[CBMutableService alloc]initWithType:[CBUUID UUIDWithString:@"0x1812"] primary:YES];
    //    [service1 setCharacteristics:@[notiyCharacteristic,readwriteCharacteristic]];
    //    //service2初始化并加入一个characteristics
    //    CBMutableService *service2 = [[CBMutableService alloc]initWithType:[CBUUID UUIDWithString:@"0x1813"] primary:YES];
    //    [service2 setCharacteristics:@[readCharacteristic]];
    //    //添加后就会调用代理的- (void)peripheralManager:(CBPeripheralManager *)peripheral didAddService:(CBService *)service error:(NSError *)error
    //    [self.manager addService:service1];
    //    [self.manager addService:service2];
    
    
}


//作为主设备的时候开始扫描
-(void)findBLEPeripheralsWithRepeat:(BOOL)isRepeat
{
    CM.delegate = self;
    // bool值，为NO，表示不会重复扫描已经发现的设备。
    NSDictionary *options = [NSDictionary dictionaryWithObject:[NSNumber numberWithBool:isRepeat] forKey:CBCentralManagerScanOptionAllowDuplicatesKey];
    [self.CM scanForPeripheralsWithServices:nil options:options];
}
//判断主机是否在扫描
-(BOOL)isScan
{
    return CM.isScanning;
}


- (void) connectPeripheral:(CBPeripheral *)peripheral {
    
    
    /*对应NSNumber的bool值，设置当外设连接后是否弹出一个警告
     NSString *const CBConnectPeripheralOptionNotifyOnConnectionKey; //对应NSNumber的bool值，设置当外设断开连接后是否弹出一个警告
     NSString *const CBConnectPeripheralOptionNotifyOnDisconnectionKey; //对应NSNumber的bool值，设置当外设暂停连接后是否弹出一个警告
     NSString *const CBConnectPeripheralOptionNotifyOnNotificationKey */
    
    /*[CM connectPeripheral:peripheral options:@{
     CBConnectPeripheralOptionNotifyOnConnectionKey: @YES,
     CBConnectPeripheralOptionNotifyOnDisconnectionKey: @YES,
     CBConnectPeripheralOptionNotifyOnNotificationKey: @YES}]; */
    activePeripheral = peripheral;
    activePeripheral.delegate = self;
    [CM connectPeripheral:activePeripheral options:nil];
}

-(void)disconnect:(CBPeripheral *)peripheral
{
    activePeripheral = peripheral;
    activePeripheral.delegate = self;
    [CM cancelPeripheralConnection:activePeripheral];
}

//激活设备
-(void)enableRead:(CBPeripheral*)p
{
    [self notification:ISSC_SERVICE_UUID characteristicUUID:ISSC_CHAR_RX_UUID p:p on:YES];
}

-(void)DisableRead:(CBPeripheral*)p
{
    [self notification:ISSC_SERVICE_UUID characteristicUUID:ISSC_CHAR_RX_UUID p:p on:NO];
}


//不过滤遍历所有服务
-(void) getAllServicesFromKeyfob:(CBPeripheral *)p{
    [p discoverServices:nil]; // Discover all services without filter
    
}
//过滤遍历所有服务 这里我并没有进行过滤
-(void) getAllCharacteristicsFromKeyfob:(CBPeripheral *)p{
    for (int i=0; i < p.services.count; i++) {
        NSLog(@"servive = %@",[p.services objectAtIndex:i]);
        CBService *s = [p.services objectAtIndex:i];
        [p discoverCharacteristics:nil forService:s];
    }
}




//查找设备指定服务
-(CBService*)FindServiceFromUUID:(NSString*)serviceUUID Peripheral:(CBPeripheral *)peripheral
{
    for (int i = 0; i<peripheral.services.count; i++) {
        CBService * service = [peripheral.services objectAtIndex:i];
        if([service.UUID.UUIDString.lowercaseString isEqualToString:serviceUUID.lowercaseString])
            return service;
    }
    return nil;
}


//查找服务的指定特征
-(CBCharacteristic *) findCharacteristicFromUUID:(NSString *)UUID service:(CBService*)service {
    for(int i=0; i < service.characteristics.count; i++) {
        CBCharacteristic *c = [service.characteristics objectAtIndex:i];
        if([UUID.lowercaseString isEqualToString:c.UUID.UUIDString.lowercaseString])
            return c;
    }
    return nil; //Characteristic not found on this service
}





-(void)writeValueUI:(NSString*)serviceUUID characteristicUUID:(NSString*)characteristicUUID p:(CBPeripheral *)p data:(NSData *)data
{
    //NSLog(@"WRITE:====:%04X, %04X", serviceUUID, characteristicUUID);
    
    
    NSString * strData = @"";
       Byte * byte = (Byte*) data.bytes;
       for (int i = 0 ; i< data.length; i++) {
        strData = [strData stringByAppendingString:[NSString stringWithFormat:@"%02x ",byte[i]]];
       }
     
        strData = [@"Send:" stringByAppendingString:[NSString stringWithFormat:@"%@",strData]];
    
    NSString * strFileName = [[NSUserDefaults standardUserDefaults] objectForKey:@"fileName"];
    if(strFileName)
        [[MyFileView sharedManager] WriteWithData:strData WithFileName:strFileName];
    
    CBService * service  = [self FindServiceFromUUID:serviceUUID Peripheral:p];
    if(!service)
    {
        NSLog(@"Could not find service with UUID %@ on peripheral",serviceUUID);
        return;
    }
    CBCharacteristic * characteristic = [self findCharacteristicFromUUID:characteristicUUID service:service];
    if(!characteristic)
    {
        NSLog(@"Could not find characteristic with UUID %@ on service with UUID %@ on peripheral",serviceUUID,characteristicUUID);
        return;
    }
    [p writeValue:data forCharacteristic:characteristic type:CBCharacteristicWriteWithoutResponse];  //ISSC
}



-(void)writeValue:(NSString*)serviceUUID characteristicUUID:(NSString*)characteristicUUID p:(CBPeripheral *)p data:(NSData *)data
{
    //NSLog(@"WRITE:====:%04X, %04X", serviceUUID, characteristicUUID);
    
    
    NSString * strData = @"";
          Byte * byte = (Byte*) data.bytes;
          for (int i = 0 ; i< data.length; i++) {
           strData = [strData stringByAppendingString:[NSString stringWithFormat:@"%02x ",byte[i]]];
          }
        
           strData = [@"Send:" stringByAppendingString:[NSString stringWithFormat:@"%@",strData]];
       
       NSString * strFileName = [[NSUserDefaults standardUserDefaults] objectForKey:@"fileName"];
       if(strFileName)
           [[MyFileView sharedManager] WriteWithData:strData WithFileName:strFileName];
    
    
    CBService * service  = [self FindServiceFromUUID:serviceUUID Peripheral:p];
    if(!service)
    {
        NSLog(@"Could not find service with UUID %@ on peripheral",serviceUUID);
        return;
    }
    CBCharacteristic * characteristic = [self findCharacteristicFromUUID:characteristicUUID service:service];
    if(!characteristic)
    {
        NSLog(@"Could not find characteristic with UUID %@ on service with UUID %@ on peripheral",serviceUUID,characteristicUUID);
        return;
    }
    [p writeValue:data forCharacteristic:characteristic type:CBCharacteristicWriteWithResponse];  //ISSC
}


-(void)readValue: (NSString*)serviceUUID characteristicUUID:(NSString*)characteristicUUID p:(CBPeripheral *)p
{
    CBService * service  = [self FindServiceFromUUID:serviceUUID Peripheral:p];
     if(!service)
     {
         NSLog(@"Could not find service with UUID %@ on peripheral",serviceUUID);
         return;
     }
     CBCharacteristic * characteristic = [self findCharacteristicFromUUID:characteristicUUID service:service];
     if(!characteristic)
     {
         NSLog(@"Could not find characteristic with UUID %@ on service with UUID %@ on peripheral",serviceUUID,characteristicUUID);
         return;
     }
    [p readValueForCharacteristic:characteristic];
}


-(void)notification:(NSString*)serviceUUID characteristicUUID:(NSString*)characteristicUUID p:(CBPeripheral *)p on:(BOOL)on
{
    CBService * service  = [self FindServiceFromUUID:serviceUUID Peripheral:p];
     if(!service)
     {
         NSLog(@"Could not find service with UUID %@ on peripheral",serviceUUID);
         return;
     }
     CBCharacteristic * characteristic = [self findCharacteristicFromUUID:characteristicUUID service:service];
     if(!characteristic)
     {
         NSLog(@"Could not find characteristic with UUID %@ on service with UUID %@ on peripheral",serviceUUID,characteristicUUID);
         return;
     }
    [p setNotifyValue:on forCharacteristic:characteristic];
}


#pragma mark  CBCentralManagerDelegate

- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    
    NSLog(@"Status of CoreBluetooth central manager changed %@",[self centralManagerStateToString:central.state]);
    
}
-(NSString*)centralManagerStateToString:(int)state
{
    
    //    CBCentralManagerStateUnknown = 0,
    //    CBCentralManagerStateResetting,
    //    CBCentralManagerStateUnsupported,
    //    CBCentralManagerStateUnauthorized,
    //    CBCentralManagerStatePoweredOff,
    //    CBCentralManagerStatePoweredOn,
    switch(state) {
        case CBManagerStateUnknown:
            return @"CBCentralManagerStateUnknown";
        case CBManagerStateResetting:
            return @"CBCentralManagerStateResetting";
        case CBManagerStateUnsupported:
            return @"CBCentralManagerStateUnsupported";
        case CBManagerStateUnauthorized:
            return @"CBCentralManagerStateUnauthorized";
        case CBManagerStatePoweredOff:
            return @"CBCentralManagerStatePoweredOff";
        case CBManagerStatePoweredOn:
            return @"CBCentralManagerStatePoweredOn";
        default:
            return @"State unknown";
    }
    return @"Unknown state";
}

//不知道干啥用的。。。
- (void)centralManager:(CBCentralManager *)central willRestoreState:(NSDictionary<NSString *, id> *)dict
{
    
}

//扫描发现外围设备的时候会调用
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary<NSString *, id> *)advertisementData RSSI:(NSNumber *)RSSI
{
    if(RSSI.intValue>0||RSSI.intValue<self.BleRSSIValue)
        return;
   
    if(self.strFilterName.length==0)
    [self.delegate FindDeviceWithDevice:peripheral RSSI:RSSI];
    else
    {
        NSString * strDeviceName = peripheral.name.lowercaseString;
        if([strDeviceName rangeOfString:self.strFilterName.lowercaseString].location !=NSNotFound)
        {
           [self.delegate FindDeviceWithDevice:peripheral RSSI:RSSI];  
        }
    }
    
}

//当中央蓝牙连接成功外围设备的时候会调用
- (void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    self.activePeripheral = peripheral;
    [self.activePeripheral discoverServices:nil];
}

//当中央蓝牙连接失败外围设备的时候会调用
- (void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(nullable NSError *)error
{
    
}


//当中央蓝牙连接外围设备由连接变成断开的时候会调用
- (void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(nullable NSError *)error
{
  
    NSLog(@"didDisconnectPeripheral error = %@",error.debugDescription);
    [self.delegate Disconnected];
    
}


#pragma mark  CBPeripheralDelegate

//外设蓝牙改变了自己的名字的时候会调用
- (void)peripheralDidUpdateName:(CBPeripheral *)peripheral
{
    
}


- (void)peripheral:(CBPeripheral *)peripheral didModifyServices:(NSArray<CBService *> *)invalidatedServices
{
    
}

- (void)peripheralDidUpdateRSSI:(CBPeripheral *)peripheral error:(nullable NSError *)error
{
    
}
- (void)peripheral:(CBPeripheral *)peripheral didReadRSSI:(NSNumber *)RSSI error:(nullable NSError *)error
{
    
}

//发现了服务并且开始遍历所有的服务
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(nullable NSError *)error
{
    
    if (!error) {
        [self getAllCharacteristicsFromKeyfob:peripheral];
    }
    else {
        NSLog(@"Service discovery was unsuccessfull !");
        
    }
    
}


- (void)peripheral:(CBPeripheral *)peripheral didDiscoverIncludedServicesForService:(CBService *)service error:(nullable NSError *)error
{
    NSLog(@"didDiscoverIncludedServicesForService");
}
//遍历完所有服务的特征值
- (void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(nullable NSError *)error
{
    
    if (!error) {
        if([[[peripheral services] lastObject] isEqual:service])
        {
            //这里就可以开始进行服务特征的使能了。。。
            if(IsRepeatConnect==YES)
            {
                [self enable];
                IsRepeatConnect = NO;
            }
            else
            [self.delegate start];
        }
    }
    else {
        NSLog(@"Characteristic discorvery unsuccessfull !");
        
    }

}




-(UInt16) CBUUIDToInt:(CBUUID *) UUID {
    char b1[16];
    [UUID.data getBytes:b1 length:16];
    return ((b1[0] << 8) | b1[1]);
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(nullable NSError *)error
{
    
    
   
    //通信的回调
    NSString * strUUID = characteristic.UUID.UUIDString;
    if(!error)
    {
        
        NSString * strData = @"";
              Byte *MyByte = (Byte *)[characteristic.value bytes];;
              for (int i = 0 ; i< characteristic.value.length; i++) {
               strData = [strData stringByAppendingString:[NSString stringWithFormat:@"%02x ",MyByte[i]]];
              }
            
               strData = [@"Receive:" stringByAppendingString:[NSString stringWithFormat:@"%@",strData]];
           
           NSString * strFileName = [[NSUserDefaults standardUserDefaults] objectForKey:@"fileName"];
           if(strFileName)
               [[MyFileView sharedManager] WriteWithData:strData WithFileName:strFileName];
        
        if([strUUID isEqualToString:ISSC_CHAR_RX_UUID])
        {
            Byte *byte = (Byte *)[characteristic.value bytes];
            [self.delegate DisplayRece:byte length:(int)characteristic.value.length];
        }
     }

}




- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForCharacteristic:(CBCharacteristic *)characteristic error:(nullable NSError *)error
{
    NSLog(@"didWriteValueForCharacteristic");
}


- (void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(nullable NSError *)error
{
    NSLog(@"didUpdateNotificationStateForCharacteristic");
}

- (void)peripheral:(CBPeripheral *)peripheral didDiscoverDescriptorsForCharacteristic:(CBCharacteristic *)characteristic error:(nullable NSError *)error
{
    NSLog(@"didDiscoverDescriptorsForCharacteristic");
}

- (void)peripheral:(CBPeripheral *)peripheral didUpdateValueForDescriptor:(CBDescriptor *)descriptor error:(nullable NSError *)error
{
    NSLog(@"didUpdateValueForDescriptor");
}

- (void)peripheral:(CBPeripheral *)peripheral didWriteValueForDescriptor:(CBDescriptor *)descriptor error:(nullable NSError *)error
{
    NSLog(@"didWriteValueForDescriptor");
}




#pragma mark  CBPeripheralManagerDelegate

-(NSString*)peripheralManagerStateToString:(int)state
{
    
    //    CBPeripheralManagerStateUnknown = 0,
    //    CBPeripheralManagerStateResetting,
    //    CBPeripheralManagerStateUnsupported,
    //    CBPeripheralManagerStateUnauthorized,
    //    CBPeripheralManagerStatePoweredOff,
    //    CBPeripheralManagerStatePoweredOn,
    switch(state) {
        case CBManagerStateUnknown:
            return @"CBPeripheralManagerStateUnknown";
        case CBManagerStateResetting:
            return @"CBPeripheralManagerStateResetting";
        case CBManagerStateUnsupported:
            return @"CBPeripheralManagerStateUnsupported";
        case CBManagerStateUnauthorized:
            return @"CBPeripheralManagerStateUnauthorized";
        case CBManagerStatePoweredOff:
            return @"CBPeripheralManagerStatePoweredOff";
        case CBManagerStatePoweredOn:
            return @"CBPeripheralManagerStatePoweredOn";
        default:
            return @"State unknown";
    }
    return @"Unknown state";
}

- (void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral
{
    [self addMyService];
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral willRestoreState:(NSDictionary<NSString *, id> *)dict
{
    NSLog(@"peripheralManager-willRestoreState");
}

- (void)peripheralManagerDidStartAdvertising:(CBPeripheralManager *)peripheral error:(nullable NSError *)error
{
    NSLog(@"peripheralManagerDidStartAdvertising");
    
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral didAddService:(CBService *)service error:(nullable NSError *)error
{
    NSLog(@"peripheralManager - didAddService");
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didSubscribeToCharacteristic:(CBCharacteristic *)characteristic
{
    if(!_subscribedCentrals)
    {
        _subscribedCentrals = [[NSMutableArray alloc]init];
    }
    [_subscribedCentrals addObject:central];
    NSLog(@"peripheralManager- didSubscribeToCharacteristic");
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didUnsubscribeFromCharacteristic:(CBCharacteristic *)characteristic
{
    NSLog(@"peripheralManager-didUnsubscribeFromCharacteristic");
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveReadRequest:(CBATTRequest *)request
{
    NSLog(@"peripheralManager-didReceiveReadRequest");
}

- (void)peripheralManager:(CBPeripheralManager *)peripheral didReceiveWriteRequests:(NSArray<CBATTRequest *> *)requests
{
    NSLog(@"peripheralManager-didReceiveWriteRequests");
}

- (void)peripheralManagerIsReadyToUpdateSubscribers:(CBPeripheralManager *)peripheral
{
    NSLog(@"peripheralManagerIsReadyToUpdateSubscribers");
}






-(void)enable
{
    [self notification:ISSC_SERVICE_UUID characteristicUUID:ISSC_CHAR_RX_UUID p:self.activePeripheral on:YES];
}
-(void)disable
{
   [self notification:ISSC_SERVICE_UUID characteristicUUID:ISSC_CHAR_RX_UUID p:self.activePeripheral on:NO];
}
-(void)startOTA
{
    uint8_t b[] = {0x47,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    int sam = 0;
    for (int i =0; i<15; i++)
        sam += b[i];
    b[15] = sam;
    NSMutableData *data = [[NSMutableData alloc] initWithBytes:b length:16];
    [self writeValue:ISSC_SERVICE_UUID characteristicUUID:ISSC_CHAR_TX_UUID p:self.activePeripheral data:data];
}

-(void)GetDeviceTime
{
    uint8_t b[] = {0x41,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    int sam = 0;
    for (int i =0; i<15; i++)
        sam += b[i];
    b[15] = sam;
    NSMutableData *data = [[NSMutableData alloc] initWithBytes:b length:16];
    [self writeValue:ISSC_SERVICE_UUID characteristicUUID:ISSC_CHAR_TX_UUID p:self.activePeripheral data:data];
}


@end
