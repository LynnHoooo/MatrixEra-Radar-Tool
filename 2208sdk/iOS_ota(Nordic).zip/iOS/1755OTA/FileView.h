//
//  FileView.h
//  固件升级(6.25)
//
//  Created by  on 17/4/28.
//  Copyright © 2017年 杨赛. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FileSelectionDelegate.h"
@protocol SetFileName
-(void)setZipFileName:(NSString*)zipFileName haveZip:(BOOL)haveZip;
-(void)SetBinFileName:(NSString*)binFileName;
-(void)SetMD5:(NSString*)strMD5;
@end
@interface FileView : UIViewController
@property(nonatomic,retain) id<SetFileName> MyFileDelegate;
@property(nonatomic,retain) NSMutableArray * arrayFile;
@property(nonatomic,retain) id<FileSelectionDelegate> delegate;
@end
