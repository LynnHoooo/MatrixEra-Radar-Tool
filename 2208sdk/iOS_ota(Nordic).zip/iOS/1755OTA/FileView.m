//
//  FileView.m
//  固件升级(6.25)
//
//  Created by  on 17/4/28.
//  Copyright © 2017年 杨赛. All rights reserved.
//

#import "FileView.h"
#import "UnzipFirmware.h"
#import "MyFileView.h"
@interface FileView ()<UITableViewDelegate,UITableViewDataSource,SetFileName,UIDocumentInteractionControllerDelegate>
{
    
    __weak IBOutlet UITableView *MyTableView;
    
    
}
- (IBAction)back:(UIButton *)sender;
- (IBAction)edit:(UIButton *)sender;

@end

@implementation FileView
@synthesize arrayFile;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    // Dispose of any resources that can be recreated.
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   
    return arrayFile.count;
   
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
     cell.textLabel.text = [arrayFile objectAtIndex:indexPath.row];
    cell.textLabel.font  =[UIFont systemFontOfSize:10];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString * strFile = [arrayFile objectAtIndex:indexPath.row];
    if([strFile rangeOfString:@"zip"].location!=NSNotFound){
        NSString * strFileName = [strFile stringByReplacingOccurrencesOfString:@"Inbox/" withString:@""];
        strFileName  = [strFileName stringByReplacingOccurrencesOfString:@".zip" withString:@""];
        BOOL success =   [[MyFileView sharedManager] CreateFile:[NSString stringWithFormat:@"%@.txt",strFileName]];
        [[NSUserDefaults standardUserDefaults] setObject:[NSString stringWithFormat:@"%@.txt",strFileName] forKey:@"fileName"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *path = [paths firstObject];
        NSString *filePath = [path stringByAppendingPathComponent:strFile];
        NSURL *fileURL = [NSURL fileURLWithPath:filePath];
        UnzipFirmware *unzipFiles = [[UnzipFirmware alloc]init];
        NSArray *firmwareFilesURL = [unzipFiles unzipFirmwareFiles:fileURL];
        
        //先判断里面是否包含zip文件
        BOOL haveZip = NO;
        for (NSURL *url in firmwareFilesURL) {
            NSString * strPath = url.path;
            NSLog(@"strPath = %@",strPath);
            if([strPath.lowercaseString hasSuffix:@"zip"]==YES)
            {
                haveZip = YES;
                break;
            }
        }
        if(haveZip==NO)
            [self.MyFileDelegate setZipFileName:filePath haveZip:NO];
        else{
            for (NSURL *url in firmwareFilesURL) {
                NSString * strPath = url.path;
                NSLog(@"strPath = %@",strPath);
                if([strPath.lowercaseString rangeOfString:@"bin"].location !=NSNotFound&&haveZip==YES)
                {
                    [self.MyFileDelegate SetBinFileName:strPath];
                }
                else if([strPath.lowercaseString rangeOfString:@"txt"].location !=NSNotFound&&haveZip==YES)
                {
                    NSString*str=[[NSString alloc] initWithContentsOfURL:url];
                    NSLog(@"str= %@",str);
                    [self.MyFileDelegate SetMD5:str];
                }
                else if([strPath.lowercaseString rangeOfString:@"zip"].location !=NSNotFound)
                {
                    [self.MyFileDelegate setZipFileName:strPath haveZip:YES];
                }
                
            }
        }
        //    [self.delegate onFileSelected:fileURL];
        [self.navigationController popViewControllerAnimated:YES];
    }
    else
    {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *path = [paths firstObject];
        NSString *filePath = [path stringByAppendingPathComponent:strFile];
        UIDocumentInteractionController *docu = [UIDocumentInteractionController interactionControllerWithURL:[NSURL fileURLWithPath:filePath]];
        
        docu.delegate = self;
        CGRect rect = CGRectMake(0, 0, 320, 300);  //这里感觉没什么用
        
        [docu presentOpenInMenuFromRect:rect inView:self.view animated:YES];  //不写可以直接预览
        
        [docu presentPreviewAnimated:YES];
    }
}

/*删除用到的函数*/
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle ==UITableViewCellEditingStyleDelete)
    {
         //删除数组里的数据
        NSString * strFile = [arrayFile objectAtIndex:indexPath.row];
        [arrayFile   removeObjectAtIndex:[indexPath row]];
        [MyTableView   deleteRowsAtIndexPaths:[NSMutableArray arrayWithObject:indexPath]withRowAnimation:UITableViewRowAnimationAutomatic];  //删除对应数据的cell
        NSFileManager* fileManager=[NSFileManager defaultManager];
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *path = [paths firstObject];
        NSString *filePath = [path stringByAppendingPathComponent:strFile];
        BOOL blHave=[[NSFileManager defaultManager] fileExistsAtPath:filePath];
        
        if(blHave)
        {
            [fileManager removeItemAtPath:filePath error:nil];
            
        }
    }
}


- ( UIViewController *)documentInteractionControllerViewControllerForPreview:( UIDocumentInteractionController *)interactionController{
    
    return self;
    
}


- (IBAction)back:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];

}

- (IBAction)edit:(UIButton *)sender {
     [MyTableView setEditing:YES animated:YES];

}
@end
