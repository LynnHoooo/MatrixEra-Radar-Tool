//
//  MainView.h
//  1755OTA
//
//  Created by  on 2018/9/4.
//  Copyright © 2018年 杨赛. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainView : UIViewController
@end
