//
//  MainView.m
//  1755OTA
//
//  Created by  on 2018/9/4.
//  Copyright © 2018年 杨赛. All rights reserved.
//

#import "MainView.h"
#import "MyBle.h"
#import "FileView.h"
#import "OTAFile.h"
#import "MBProgressHUD.h"
#import "PishumToast.h"
#import "SoureOTAFile.h"
#import "MyFileView.h"
extern BOOL IsOTA;
@interface MainView ()<UITableViewDelegate,UITableViewDataSource,MyBleDelegate,SetFileName,MBProgressHUDDelegate,SourceProgressDelegate,MyOTAStatusDelegate>
{
    BOOL needSourceOTA;// zip里面包含zip的
    BOOL OTASucced;
    MBProgressHUD * HUD;
    UITableView * myTableView;
    NSString * strPathZipName;
    NSString * strMD5;
    NSString * strPathBin;
    __weak IBOutlet UILabel *labZipName;
    __weak IBOutlet UILabel *labBinName;
    __weak IBOutlet UILabel *labMD5;
    
    __weak IBOutlet UILabel *labProgress;
    
}

@property (weak, nonatomic) IBOutlet UIButton *btnSelectFile;
@property (weak, nonatomic) IBOutlet UIButton *btnScanDevice;
@property (weak, nonatomic) IBOutlet UIButton *btnOtaAll;
@property (weak, nonatomic) IBOutlet UIButton *btnOtaSource;
@property (weak, nonatomic) IBOutlet UIButton *btnDeleteSourceFile;
@property (weak, nonatomic) IBOutlet UIButton *btnLog;

@property (weak, nonatomic) IBOutlet UITextView *myTextView;

@property (nonatomic,strong)NSMutableArray * arrayPeripheral;
@property (nonatomic,strong)NSMutableArray * arrayRSSI;
@property (strong, nonatomic) IBOutlet UIScrollView *myScrollView;

- (IBAction)selectFile:(UIButton *)sender;
- (IBAction)scan:(UIButton *)sender;
@end

@implementation MainView

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _arrayPeripheral = [[NSMutableArray alloc] init];
    _arrayRSSI = [[NSMutableArray alloc] init];
    
    _btnSelectFile.layer.cornerRadius =  17.5;
    _btnScanDevice.layer.cornerRadius =  17.5;
    _btnOtaAll.layer.cornerRadius =  17.5;
    _btnOtaSource.layer.cornerRadius =  17.5;
    _btnDeleteSourceFile.layer.cornerRadius =  17.5;
    _btnLog.layer.cornerRadius =  17.5;
    
    [[UIApplication sharedApplication] setIdleTimerDisabled:YES] ;
    [[MyBle sharedManager] CentralManagerSetUp];
    [MyBle sharedManager].delegate = self;
    [OTAFile sharedManager].delegate = self;
 
    
    [SoureOTAFile sharedManager].delegate = self;
    
    [self.view addSubview:_myScrollView];
    _myScrollView.frame = CGRectMake(0, 70, 320, 480);
    
    [_myScrollView setContentSize:CGSizeMake(320, 1000)];
    
    
    
    myTableView = [[UITableView alloc]initWithFrame:CGRectMake(10, 100, 300,400 )];
    myTableView.delegate = self;
    myTableView.dataSource = self;
    myTableView.tableFooterView = [self FootView];
    myTableView.tableHeaderView = [self HeaderView];
    
    myTableView.layer.borderWidth = 1.0f;
    myTableView.layer.cornerRadius = 10;
    myTableView.layer.borderColor = [UIColor colorWithRed:154.0/255.0 green:202/255.0 blue:124/255.0 alpha:1].CGColor;
    [self.view addSubview:myTableView];
    [myTableView setHidden:YES];
    
    

    
    _myTextView.text = @"Please follow up the following steps for OTA:\nStep 1: Download the firmware zip file and open by Jstyle-Nordic OTA APP\nStep 2: Click “Select file” for correct firmware zip file\nStep 3: Click “Scan” to choose the right device you want to update with the new firmware\nStep 4: Click “OTA” to start the firmware update process.\nStep 4: The OTA process will start from 0%-100% to show the OTA success.\n\nNote: In case the OTA failed, the bluetooth device name will changed to “DFUxxx”， please repeat the above steps and Scan the DFU device to try the OTA again.\n\n\n请按照以下步骤进行固件升级 OTA：\n步骤 1：下载后缀名为Zip 的固件压缩文件，并选择在Jstyle-Nordic OTA APP 打开\n步骤 2：点击“选择文件Select“File，选择要升级的固件版本\n步骤 3：点击”扫描Scan”，选择要更新的蓝牙设备\n步骤 4：点击 “OTA ”开始固件升级， 升级过程中进度会从0-100%， 100%显示升级成功。\n\n注意：若 OTA 固件升级失败，蓝牙设备名将变为 “DFUxxx”，请重复上述步骤， 但是步骤2选择扫描 设备名变为DFU 的产品，再次尝试 OTA即可。";
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark headViewAndFootView
-(UIView*)HeaderView
{
    //    UIView* headerview=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 300*CurrentWidth/MyWidth, 120*CurrentWidth/MyWidth)];
    UILabel * labTitle = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 300, 60)];
    labTitle.text = NSLocalizedString(@"设备列表", nil);
    labTitle.textColor = [UIColor colorWithRed:154.0/255.0 green:202/255.0 blue:124/255.0 alpha:1];
    labTitle.textAlignment = NSTextAlignmentCenter;
    labTitle.backgroundColor = [UIColor clearColor];
    //    [headerview addSubview:labTitle];
    return labTitle;
}
-(UIView*)FootView
{
    UIView* headerview=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 300, 40)];
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 148, 38)];
    NSString * str = NSLocalizedString(@"取消", nil);
    [btn setBackgroundImage:[UIImage imageNamed:@"按钮_下一步.png"] forState:UIControlStateNormal];
    [btn setTitle:str forState:UIControlStateNormal];
    //    btn.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 10*CurrentWidth/MyWidth, 0);
    [btn setTitleColor:  [UIColor colorWithRed:154.0/255.0 green:202/255.0 blue:124/255.0 alpha:1]forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(Cancle) forControlEvents:UIControlEventTouchUpInside];
    [headerview addSubview:btn];
    btn.center =  headerview.center;
    headerview.backgroundColor = [UIColor clearColor];
    return headerview;
}

-(void)Cancle
{
    [[MyBle sharedManager].CM stopScan];
    [_arrayPeripheral removeAllObjects];
    [_arrayRSSI removeAllObjects];
    [myTableView setHidden:YES];
}

#pragma mark Table View Data Source delegate methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return _arrayPeripheral.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    @try {
        NSString * str = ((CBPeripheral*)[_arrayPeripheral objectAtIndex:indexPath.row]).name;
        if(str.length==0)
            str = @"style";
        if(str.length<18)
        {
            int length = (int)str.length;
            for (int i =0 ; i<18-length; i++) {
                str = [str stringByAppendingString:@" "];
            }
        }
        [cell.textLabel setText:[str stringByAppendingString:[NSString stringWithFormat:@"📶%@",[_arrayRSSI objectAtIndex:indexPath.row]]]];
        
        cell.textLabel.font = [UIFont fontWithName:@"Courier" size:14];
      
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
 
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    

    OTASucced = NO;
    [[MyBle sharedManager].CM stopScan];
    [[MyBle sharedManager].CM stopScan];
    if([((CBPeripheral*)[_arrayPeripheral objectAtIndex:indexPath.row]).name.lowercaseString hasPrefix:@"dfu"])
    {
        [[OTAFile sharedManager] SetBleCenter:[MyBle sharedManager].CM Peripheral:[_arrayPeripheral objectAtIndex:indexPath.row]];
        [self performSelector:@selector(OTA) withObject:nil afterDelay:2];
    }
    else
    {
        if(HUD==nil)
        {
            HUD = [[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            HUD.delegate = self;
            [HUD showWhileExecuting:@selector(myTask:) onTarget:self withObject:[NSNumber numberWithInt:60] animated:YES];
        }
        HUD.detailsLabel.text =NSLocalizedString(@"正在连接设备...\nConnecting the device now...",nil);
        [[MyBle sharedManager] connectPeripheral:[_arrayPeripheral objectAtIndex:indexPath.row]];
    }
    
    
    [tableView setHidden:YES];
}

#pragma mark enterOTAMode
-(void)enterOTAMode
{
    //
    NSLog(@"enterOTAMode");
    [[MyBle sharedManager] startOTA];
    IsOTA = YES;
    [[MyBle  sharedManager] findBLEPeripheralsWithRepeat:YES];
}

#pragma mark MyOTAStatusDelegate
-(void)MyOTAStatusDelegate:(NSString *)message centralManager:(CBCentralManager *)centralManager
{
    NSLog(@"message = %@",message);
//    if([message isEqualToString:@"Device disconnected unexpectedly"]||[message isEqualToString:@"Disconnected by the remote device"])
//    {
        //重新连接
        [self  performSelector:@selector(enterOTAMode) withObject:nil afterDelay:2];
    
//    }
}

#pragma mark OTA
-(void)OTA
{

    [[OTAFile sharedManager] onFileSelected:[NSURL URLWithString:strPathZipName]];
    [[OTAFile sharedManager] startOTA];
      [OTAFile sharedManager].callBackBlock = ^(NSInteger progress)
      {
          if(progress==100)
          {
              NSLog(@"OTA 完成");
              labProgress.text = @"100%";
              [MyBle sharedManager].CM.delegate = [MyBle sharedManager];
              [self performSelector:@selector(complete) withObject:nil afterDelay:3];
              HUD.detailsLabel.text = NSLocalizedString(@"Firmware Updated Successfully!", nil) ;
              
          }
          else
          {
              if(HUD==nil)
              {
                  HUD = [[MBProgressHUD alloc] initWithView:self.view];
                  [self.view addSubview:HUD];
                  HUD.delegate = self;
                  [HUD showWhileExecuting:@selector(myTask:) onTarget:self withObject:[NSNumber numberWithInt:60] animated:YES];
              }
              HUD.label.text =NSLocalizedString(@"Firmware Update",nil);
              HUD.detailsLabel.text = [NSString stringWithFormat:@"%@:%lu%%",NSLocalizedString(@"Progress", nil),progress];
              labProgress.text = [NSString stringWithFormat:@"%lu%%",progress];
          }
      };
}

-(void)myOTA
{
  
}

-(void)myTask:(NSNumber*)sleepTime
{
    sleep(sleepTime.intValue);
}

-(void)complete
{
    IsOTA = NO;
    OTASucced = YES;
    [self hudWasHidden:HUD];
    [self startConnectDevice];
}


-(void)startConnectDevice
{
    
    
    
    NSString *  identifier = [[NSUserDefaults standardUserDefaults] objectForKey:@"identifier"];
    if(identifier){
        HUD = [[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:HUD];
        HUD.delegate = self;
        HUD.detailsLabelText = NSLocalizedString(@"Connecting device...", nil);
        [HUD showWhileExecuting:@selector(myTask:) onTarget:self withObject:[NSNumber numberWithInt:5] animated:YES];
        //进行了设备绑定
        //检查是否系统蓝牙已经连接
        NSUUID * uuid = [NSUUID UUID];
        uuid = [uuid initWithUUIDString:identifier];
        NSArray * bleArray = [[MyBle sharedManager].CM  retrievePeripheralsWithIdentifiers:[NSArray arrayWithObject:uuid]];
        if(bleArray.count>0)
        {
            //            [MyBle sharedManager].activePeripheral = [bleArray.lastObject copy];
            //            [MyBle sharedManager].delegate = self;
            [[MyBle sharedManager] connectPeripheral:bleArray.lastObject];
        }
    }
}

#pragma mark MBProgressHUDDelegate
-(void)hudWasHidden:(MBProgressHUD *)hud
{
    if(hud)
    {
        [HUD removeFromSuperview];
        HUD = nil;
    }
}




#pragma mark MyBleDelegate
-(void)FindDeviceWithDevice:(CBPeripheral*)device  RSSI:(NSNumber*)RSSI
{
 
    NSLog(@"deviceName = %@",device.name);
    if(IsOTA==YES)
    {
        if([device.name.lowercaseString rangeOfString:@"dfu"].location!=NSNotFound&&device.name.length>0)
        {
//            selectedPeripheral = device;
//            centralManager = [MyBle sharedManager].CM;
            [[OTAFile sharedManager] SetBleCenter:[MyBle sharedManager].CM Peripheral:device];
            [self OTA];
        }
    }
    else
    {
        
        if(RSSI.intValue<-70||RSSI.intValue>=0)
            return;
        if([_arrayPeripheral containsObject:device])
        {
            [_arrayRSSI replaceObjectAtIndex:[_arrayPeripheral indexOfObject:device] withObject:RSSI];
        }
        else
        {
            [_arrayPeripheral addObject:device];
            [_arrayRSSI addObject:RSSI];
        }
        if(myTableView.hidden)
            [myTableView setHidden:NO];
        [myTableView reloadData];
    }
}
//开始通信
-(void)DisplayRece:(Byte*)buf length:(int)len
{
    
    switch (buf[0]) {
        case 0x90:
        {
            //需不需要升级
            if(buf[1]==1)
            {
                //状态
                int status = buf[2];
                if(status==0)
                {
                     [PishumToast showToastWithMessage:@"当前的资源文件是最新的 不需要升级" Length:TOAST_SHORT ParentView:self.view];
        
                }else if (status==1)
                {
                    int startLocation = buf[3];
                    if(len==11)
                        [[SoureOTAFile sharedManager] check1024CRCWithLocath:startLocation];
                    else
                        [[SoureOTAFile sharedManager] sendDataWithLocation:startLocation];
                    
                }else if (status==2)
                {
                    NSLog(@"失败");
                }
            }
            else if (buf[1]==0x70)
            {
                 HUD.label.text = NSLocalizedString(@"Erased resource file successfully!", nil);
                [self performSelector:@selector(hudWasHidden:) withObject:HUD afterDelay:1];
             
            }
            else if (buf[1]==0x10)
            {
                
                //发送最后一条
                [[SoureOTAFile sharedManager] sendLastData];
                
            }else if (buf[1]==2)
            {
                if(buf[2]==1)
                {
                    [PishumToast showToastWithMessage:@"升级资源文件成功!" Length:TOAST_SHORT ParentView:self.view];
                    [[SoureOTAFile sharedManager] CleadData];
                }
                else
                {
                    //重新开始升级
                    //开始升级
                    [[SoureOTAFile sharedManager] FirstStepWithType:1];
                }
            }
        }
            break;
        case 0x91:
        {
            if(buf[1]==1)
            {
                NSLog(@"block成功!");
                [[SoureOTAFile sharedManager] CleadData];
                if([SoureOTAFile sharedManager].CurrentBlock==[SoureOTAFile sharedManager].arrayDetailTemp.count-1)
                {
                    [[SoureOTAFile sharedManager] FirstStepWithType:2];
                }
                else
                {
                    //开始发送下一块
                    [SoureOTAFile sharedManager].CurrentBlock +=1;
                    [[SoureOTAFile sharedManager] sendDataWithLocation:[SoureOTAFile sharedManager].CurrentBlock];
                }
            }
            else if(buf[1]==0xfe)
            {
                if(buf[4]==0)
                    [[SoureOTAFile sharedManager] sendDataWithLocation:[SoureOTAFile sharedManager].CurrentBlock];
                else
                {
                    [SoureOTAFile sharedManager].CurrentBlock +=1;
                    [[SoureOTAFile sharedManager] check1024CRCWithLocath:[SoureOTAFile sharedManager].CurrentBlock];
                }
            }
            else
            {
                // NSLog(@"block失败!");
                if([SoureOTAFile sharedManager].arrayReceiveCRCCheck==nil)
                    [SoureOTAFile sharedManager].arrayReceiveCRCCheck = [[NSMutableArray alloc] init];
                [[SoureOTAFile sharedManager].arrayReceiveCRCCheck removeAllObjects];
                for (int i=0; i<(len-4)/2; i++) {
                    [[SoureOTAFile sharedManager].arrayReceiveCRCCheck addObject:[NSString stringWithFormat:@"%02x%02x",buf[2+2*i],buf[3+2*i]]];
                }
                [[SoureOTAFile sharedManager] sendDataWithLocation:[SoureOTAFile sharedManager].CurrentBlock];
            }
        }
            break;
        case 0x41:
        {
            int lenght = buf[8];
            [[SoureOTAFile sharedManager] SetLenghtUnit:lenght];
            [[SoureOTAFile sharedManager]  readDataFromFilePath:strPathBin];
            [[SoureOTAFile sharedManager] GetStrMD5:labMD5.text];
            //开始升级
           [[SoureOTAFile sharedManager] FirstStepWithType:1];
        }
            break;
        default:
            break;
    }
}
-(void)Disconnected
{
    
    //
    NSLog(@"蓝牙断开了");
    [[MyBle sharedManager] connectPeripheral:[MyBle sharedManager].activePeripheral];
}
-(void)start
{
    
    
  
    HUD.detailsLabel.text = @"设备连接成功\nDevice Connected Successfully";
    [HUD hideAnimated:YES afterDelay:2];
    [[MyBle sharedManager] enable];
    [[NSUserDefaults standardUserDefaults] setObject:[MyBle sharedManager].activePeripheral.identifier.UUIDString forKey:@"identifier"];
    NSString * strName = [MyBle sharedManager].activePeripheral.name;
    if(OTASucced==YES&&needSourceOTA==YES&&[strName rangeOfString:@"2301"].location==NSNotFound)
    {
        [PishumToast showToastWithMessage:@"连接成功,开始检测资源文件" Length:TOAST_SHORT ParentView:self.view];
        // 先计算每次发送的长度
        [[MyBle sharedManager] GetDeviceTime];
        
    }
    else
    {
        
//        [self enterOTAMode];
    }
}

#pragma mark 资源文件升级

-(void)MySourceProgress:(float)progress
{
    if(progress>1)
    {
        progress =1;
        [self hudWasHidden:HUD];
        return;
    }
    if(HUD==nil)
    {
        HUD = [[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:HUD];
        HUD.delegate = self;
        [HUD showWhileExecuting:@selector(myTask:) onTarget:self withObject:[NSNumber numberWithInt:60] animated:YES];
    }
    HUD.label.text = NSLocalizedString(@"Source File Update", nil);
    HUD.detailsLabel.text = [NSString stringWithFormat:@"%@:%.0f%%",NSLocalizedString(@"Progress", nil),progress*100];
    labProgress.text = [NSString stringWithFormat:@"%.0f%%",progress*100];
    NSLog(@"progress = %.0f%%",progress*100);
  
}

#pragma mark
-(void)setZipFileName:(NSString*)zipFileName haveZip:(BOOL)haveZip
{
    NSLog(@"zipName = %@",zipFileName);
    strPathZipName = zipFileName;
    if(haveZip==YES){
        needSourceOTA = YES;
        NSString * strName = [zipFileName substringFromIndex:[zipFileName rangeOfString:@"UnzipFiles/"].location+11];
        labZipName.text = strName;
    }
    else
    {
        needSourceOTA = NO;
        NSString * strName = [zipFileName substringFromIndex:[zipFileName rangeOfString:@"Inbox/"].location+6];
        labZipName.text = strName;
    }
}
-(void)SetBinFileName:(NSString*)binFileName
{
    strPathBin = binFileName;
     NSLog(@"binFileName = %@",binFileName);
    NSString * strName = [binFileName substringFromIndex:[binFileName rangeOfString:@"UnzipFiles/"].location+11];
    NSLog(@"strName= %@",strName);
    labBinName.text = strName;
    
}
-(void)SetMD5:(NSString*)strMD5
{
    strMD5 = strMD5;
    NSLog(@"strMD5 = %@",strMD5);
    labMD5.text = strMD5;
}


- (IBAction)selectFile:(UIButton *)sender {
    
    labZipName.text = @"---";
    labBinName.text = @"---";
    labMD5.text = @"---";
    
    NSMutableArray * Myfiles = [[NSMutableArray alloc] init];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [paths firstObject];
    NSDirectoryEnumerator *enumrator = [fileManager enumeratorAtPath:path];
    NSString *file;
    file = [file lowercaseString];
    while (file = [enumrator nextObject])
    {
        NSLog(@"file = %@",file);
        if([file hasSuffix:@"zip"]||[file hasSuffix:@"hex"])
        {
            [Myfiles addObject:file];
        }
    }
    
    if(Myfiles.count==0)
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"No zip upgrade file" message:nil delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    else
    {
       
        
        
        
        FileView * fileView = [[FileView alloc] init];
        fileView.MyFileDelegate = self;
        fileView.arrayFile = [[NSMutableArray alloc] init];
        fileView.arrayFile = Myfiles;
        [self.navigationController pushViewController:fileView animated:YES];
    }
}

- (IBAction)scan:(UIButton *)sender {
  
    
    
    if(strPathZipName.length==0&&strPathBin.length==0)
    {
        UIAlertView * alert = [[UIAlertView alloc]initWithTitle:@"Please select upgrade file" message:nil delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alert show];
    }
    else
    {
        [_arrayPeripheral removeAllObjects];
        [_arrayRSSI removeAllObjects];
          NSArray * arrayConnectPeripheral = [[MyBle sharedManager].CM retrieveConnectedPeripheralsWithServices:@[[CBUUID UUIDWithString:@"fff0"]]];
        if(arrayConnectPeripheral.count>0)
        {
            for (int i = 0; i<arrayConnectPeripheral.count; i++) {
                [_arrayPeripheral addObject:arrayConnectPeripheral[i]];
                [_arrayRSSI addObject:[NSNumber numberWithInt:0]];
                [myTableView reloadData];
            }
        }
    
        [[MyBle sharedManager] findBLEPeripheralsWithRepeat:YES];
    }
    
}

- (IBAction)ota:(UIButton *)sender {
    if([MyBle sharedManager].activePeripheral.state==2)
    {
        [self enterOTAMode];
        if(HUD==nil)
        {
            HUD = [[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            HUD.delegate = self;
            [HUD showWhileExecuting:@selector(myTask:) onTarget:self withObject:[NSNumber numberWithInt:60] animated:YES];
        }
        HUD.detailsLabel.text = NSLocalizedString(@"准备升级中...\nPreparing for OTA...", nil);
    }
    else
        [PishumToast showToastWithMessage:@"the device is not connected" Length:TOAST_SHORT ParentView:self.view];
}
- (IBAction)sourceOTA:(UIButton *)sender {
    if([MyBle sharedManager].activePeripheral.state==2)
        // 先计算每次发送的长度
        [[MyBle sharedManager] GetDeviceTime];
    
    else
        [PishumToast showToastWithMessage:@"the device is not connected" Length:TOAST_SHORT ParentView:self.view];
}

- (IBAction)eraseResourceFiles:(UIButton *)sender {
    
    
    if([MyBle sharedManager].activePeripheral.state==2)
    {
        if(HUD==nil)
        {
            HUD = [[MBProgressHUD alloc] initWithView:self.view];
            [self.view addSubview:HUD];
            HUD.delegate = self;
            [HUD showWhileExecuting:@selector(myTask:) onTarget:self withObject:[NSNumber numberWithInt:60] animated:YES];
        }
        HUD.label.text = NSLocalizedString(@"Erasing resource file...", nil);
        [[SoureOTAFile sharedManager] EraseResourceFiles];
    }
    else
    {
        [PishumToast showToastWithMessage:@"the device is not connected" Length:TOAST_SHORT ParentView:self.view];
    }
}

- (IBAction)selectBugFile:(UIButton *)sender {
    NSMutableArray * Myfiles = [[NSMutableArray alloc] init];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [paths firstObject];
    NSDirectoryEnumerator *enumrator = [fileManager enumeratorAtPath:path];
    NSString *file;
    file = [file lowercaseString];
    while (file = [enumrator nextObject])
    {
        if([file hasSuffix:@"txt"])
        {
            [Myfiles  addObject:file];
        }
    }
    FileView * fileView = [[FileView alloc] init];
    fileView.arrayFile = [[NSMutableArray alloc] init];
    fileView.arrayFile = Myfiles;
    [self.navigationController pushViewController:fileView animated:YES];
}



@end
