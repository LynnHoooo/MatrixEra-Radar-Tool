//
//  main.m
//  1755OTA
//
//  Created by  on 2018/9/4.
//  Copyright © 2018年 杨赛. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
