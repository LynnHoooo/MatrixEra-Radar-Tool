//
//  MyBle.h
//  MyBle
//
//  Created by  on 16/5/25.
//  Copyright © 2016年 杨赛. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
#import <CoreBluetooth/CBService.h>
#import "BleDefines.h"
typedef struct INFO{
    int gender;
    int age;
    int heigth;
    int weight;
    int stride;
}info;

typedef struct ALARM{
    int phone;
    int message;
    int QQ;
    int WeiXin;
}MyAlarm;

typedef struct CLOCK{
    int number;
    int type;
    int hour;
    int minute;
    int week7;
    int week1;
    int week2;
    int week3;
    int week4;
    int week5;
    int week6;
}MyClock;

typedef struct DeviceTime {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
} MyDeviceTime;


typedef struct ACTIVITYALARM{
    int startHour;
    int startMinute;
    int endHour;
    int endMinute;
    int week;
    int intervalTime;
    int leastStep;
} MyActivityAlarm;


#pragma mark 蓝牙代理服务
@protocol MyBleDelegate
@required
-(void)FindDeviceWithDevice:(CBPeripheral*)device  RSSI:(NSNumber*)RSSI;
//开始通信
-(void)DisplayRece:(Byte*)buf length:(int)len;
-(void)Disconnected;
-(void)start;



@end
//DFU
@protocol MyDfuDelegate
@optional
-(void)onDeviceConnectedWithVersion:(CBPeripheral *)peripheral
           withPacketCharacteristic:(CBCharacteristic *)dfuPacketCharacteristic
      andControlPointCharacteristic:(CBCharacteristic *)dfuControlPointCharacteristic
           andVersionCharacteristic:(CBCharacteristic *)dfuVersionCharacteristic;
-(void)onDeviceConnected:(CBPeripheral *)peripheral
withPacketCharacteristic:(CBCharacteristic *)dfuPacketCharacteristic
andControlPointCharacteristic:(CBCharacteristic *)dfuControlPointCharacteristic;
-(void)onDeviceDisconnected:(CBPeripheral *)peripheral;
-(void)onReceivedNotification:(NSData *)data;
-(void)onReadDfuVersion:(int)version;
-(void)onError:(NSString *)errorMessage;
@end


@interface MyBle : NSObject<CBCentralManagerDelegate, CBPeripheralDelegate,CBPeripheralManagerDelegate>
{
     
}


@property (strong, nonatomic)CBCharacteristic *dfuPacketCharacteristic;
@property (strong, nonatomic)CBCharacteristic *dfuControlPointCharacteristic;
@property (strong, nonatomic)CBCharacteristic *dfuVersionCharacteristic;




@property (strong, nonatomic) CBCentralManager *CM;
@property (strong, nonatomic)CBPeripheralManager * manager;
@property (strong, nonatomic) CBPeripheral *activePeripheral;
@property(nonatomic,retain) NSMutableArray *_subscribedCentrals;
@property(nonatomic,retain) CBMutableCharacteristic* mycharacteristic;
@property (nonatomic,retain)id<MyBleDelegate>delegate;
@property (nonatomic,strong)id<MyDfuDelegate>DfuDelegate;

@property BOOL  isDfuTarg;
@property (nonatomic,retain) NSString * strIdentifier;
@property int BleRSSIValue;
@property (nonatomic,retain) NSString * strFilterName;
+(MyBle *)sharedManager;
-(void)enableRead:(CBPeripheral*)p;
-(void)DisableRead:(CBPeripheral*)p;

-(void)CentralManagerSetUp;
-(void)PeripheralManagerSetUp;
-(void)findBLEPeripheralsWithRepeat:(BOOL)isRepeat;
-(BOOL)isScan;
-(void)connectPeripheral:(CBPeripheral *)peripheral;
-(void)disconnect:(CBPeripheral *)peripheral;
-(void)writeValue:(NSString*)serviceUUID characteristicUUID:(NSString*)characteristicUUID p:(CBPeripheral *)p data:(NSData *)data;
-(void)writeValueUI:(NSString*)serviceUUID characteristicUUID:(NSString*)characteristicUUID p:(CBPeripheral *)p data:(NSData *)data;
-(void)readValue: (NSString*)serviceUUID characteristicUUID:(NSString*)characteristicUUID p:(CBPeripheral *)p;

-(void)addMyService;


#pragma mark bluetoothApi

-(void)enable;
-(void)disable;
-(void)startOTA;
-(void)GetDeviceTime;
@end
