//
//  OTAFile.h
//  1755OTA
//
//  Created by  on 2018/9/4.
//  Copyright © 2018年 杨赛. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <iOSDFULibrary/iOSDFULibrary-Swift.h>
@protocol MyOTAStatusDelegate
-(void)MyOTAStatusDelegate:(NSString*)message centralManager:(CBCentralManager*)centralManager;
@end
typedef void(^CallBackBlcok) (NSInteger progress);//1
@interface OTAFile : NSObject<DFUServiceDelegate,DFUProgressDelegate,LoggerDelegate>
{
    
}
@property (nonatomic,retain) id<MyOTAStatusDelegate>delegate;
@property (nonatomic,copy)CallBackBlcok callBackBlock;
#pragma mark 固件升级相关
@property (strong, nonatomic) DFUServiceController *controller;
@property (strong, nonatomic) CBPeripheral *selectedPeripheral;
@property (strong, nonatomic) CBCentralManager *centralManager;

@property (strong, nonatomic) DFUFirmware *selectedFirmware;
@property (strong, nonatomic) NSURL *selectedFileUrl;
@property (strong, nonatomic) NSURL *selectedFileDataUrl;

+(OTAFile *)sharedManager;
-(void)SetBleCenter:(CBCentralManager*)center Peripheral:(CBPeripheral*)peripheral;
-(void)startOTA;
-(void)onFileSelected:(NSURL *)fileURL;

@end
