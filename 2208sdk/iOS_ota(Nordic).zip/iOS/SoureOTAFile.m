//
//  SoureOTAFile.m
//  1755OTA
//
//  Created by  on 2018/9/5.
//  Copyright © 2018年 杨赛. All rights reserved.
//

#import "SoureOTAFile.h"
#import "MyBle.h"

@implementation SoureOTAFile
@synthesize arraySendCRCCheck,arrayReceiveCRCCheck,CurrentBlock,arrayDetailTemp;



+(SoureOTAFile *)sharedManager
{
    static SoureOTAFile *sharedAccountManagerInstance = nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        sharedAccountManagerInstance = [[self alloc] init];
    });
    return sharedAccountManagerInstance;
}
#pragma mark CRC

-(unsigned int) CRC16:(unsigned char *)buf :(unsigned int)length
{
    unsigned int i;
    unsigned int j;
    unsigned int c;
    unsigned int crc = 0xFFFF;   //设置crc寄存器为0xffff
    for (i=0; i<length; i++)
    {
        c = (buf[i]) & 0x00FF;
        crc^=c;
        for (j=0; j<8; j++)
        {
            if (crc & 0x0001)
            {
                crc >>= 1;
                crc ^= 0xA001;
            }
            else
            {
                crc >>= 1;
            }
        }
    }
    return(crc);
}

#pragma mark 读取数据

-(void)SetLenghtUnit:(int)lenght
{
    ableLength = lenght;
}
-(void)GetStrMD5:(NSString *)strMD5
{
    
    strMyMD5 = strMD5;
}

-(void)readDataFromFilePath:(NSString*)strFile
{
    
      [arrayReceiveCRCCheck removeAllObjects];
     [arraySendCRCCheck removeAllObjects];
    
    
    //
    if(arrayTemp==nil)
        arrayTemp = [[NSMutableArray alloc] init];
    [arrayTemp removeAllObjects];
    NSFileHandle* fh = [NSFileHandle fileHandleForReadingAtPath:strFile];
    NSData * data = [fh readDataToEndOfFile];
    dataLength =(unsigned int) data.length;
    p  =(unsigned char*) [data bytes];
    //对数据进行校验
    CRC = 0xFFFF;
    unsigned int c = 0,j = 0 ;
    for(int i = 0 ;i<dataLength;i++)
    {
        
        [arrayTemp addObject:[NSNumber numberWithInt:p[i]]];
        c = (p[i]) & 0x00FF;
        CRC^=c;
        for (j=0; j<8; j++)
        {
            if (CRC & 0x0001)
            {
                CRC >>= 1;
                CRC ^= 0xA001;
            }
            else
            {
                CRC >>= 1;
            }
        }
    }
    [self dealToalData];
}

#pragma mark 对总数据进行分块
-(void)dealToalData
{
    if(arrayDetailTemp==nil)
        arrayDetailTemp = [[NSMutableArray alloc] init];
    [arrayDetailTemp removeAllObjects];
    if(arrayBlockCRC==nil)
        arrayBlockCRC = [[NSMutableArray alloc] init];
    [arrayBlockCRC removeAllObjects];
    
    int max= 4096;//几个分割一次
    int segment= dataLength / max + (dataLength % max== 0 ? 0 : 1);//需要分割几次
   // labTotalBlock.text = [NSString stringWithFormat:@"%d",segment];
    for (int i= 0;i<segment;i++){
        NSUInteger star= i*max; //开始位置
        NSUInteger end= (i==(segment-1))?(dataLength-i*max)%(max+1):max; //结束位置
        //     NSLog(@"%d,%d",star,end);
        NSRange range= NSMakeRange(star,end); //分割范围
        NSArray *subArray= [[arrayTemp copy] subarrayWithRange:range];//开始抽取
        [arrayDetailTemp addObject:subArray];
        unsigned int c = 0;
        unsigned int TempCRC = 0xFFFF;
        for (int j = 0; j<subArray.count; j++) {
            int temp = ((NSNumber*)subArray[j]).intValue;
            c = temp & 0x00FF;
            TempCRC^=c;
            for (int m=0; m<8; m++)
            {
                if (TempCRC & 0x0001)
                {
                    TempCRC >>= 1;
                    TempCRC ^= 0xA001;
                }
                else
                {
                    TempCRC >>= 1;
                }
            }
        }
       
        NSLog(@"crc = %x",TempCRC);
        [arrayBlockCRC addObject:[NSNumber numberWithInt:TempCRC]];
    }
//     [self  getTotalPackage];
}

#pragma mark 计算总共需要发送包的个数
-(void)getTotalPackage
{
    //为什么要发4098
    int tempAbleLength =ableLength-6;
    tempAbleLength -=tempAbleLength%4;
    NSUInteger allCount = 4098/tempAbleLength+(4098%tempAbleLength==0?0:1)+1;
    NSUInteger tempPackage = allCount*(arrayBlockCRC.count-1);
    //计算最后一个块需要发送的包数
    NSArray * arrayData = [arrayDetailTemp lastObject];
    //每次最大发送的数据量
    allCount = (arrayData.count+2)/tempAbleLength+((arrayData.count+2)%tempAbleLength==0?0:1)+1;
    tempPackage = tempPackage +allCount;
    totalPackage = (int)tempPackage;
    
}



#pragma mark 发送步骤

//需不需要升级  如果需要从哪里开始升
-(void)FirstStepWithType:(int)type
{
    
    uint8_t b[26];
    b[0] = 0x90;
    b[1] = type;
    b[2] = dataLength%256;
    b[3] = dataLength%(256*256)/256;
    b[4] = dataLength%(256*256*256)/(256*256);
    b[5] = dataLength/(256*256*256);
    //(int)strtoul([text_1.text UTF8String], 0, 16)
    for (int i = 0; i<16; i++) {
        NSString * strMD5 = [strMyMD5 substringWithRange:NSMakeRange(2*i, 2)];
        NSLog(@"strMD5 = %@",strMD5);
        b[i+6] = (int)strtoul([strMD5 UTF8String], 0, 16);
    }
    b[22] = CRC%256;
    b[23] = CRC/256;
    
     unsigned int c = 0;
     
    unsigned int TempCRC = 0xFFFF;
    //= [self CRC16:b :26];
    
    for (int j = 0; j<24; j++) {
        int temp = b[j];
        c = temp & 0x00FF;
        TempCRC^=c;
        for (int m=0; m<8; m++)
        {
            if (TempCRC & 0x0001)
            {
                TempCRC >>= 1;
                TempCRC ^= 0xA001;
            }
            else
            {
                TempCRC >>= 1;
            }
        }
    }
    
    b[24] = TempCRC%256;
    b[25] = TempCRC/256;
//    for (int i = 0; i<26; i++) {
//        printf("%02x ",b[i]);
//    }
    NSMutableData *data = [[NSMutableData alloc] initWithBytes:b length:26];
    [[MyBle sharedManager] writeValue:ISSC_SERVICE_UUID characteristicUUID:ISSC_CHAR_TX_UUID p:[MyBle sharedManager].activePeripheral data:data];
}



-(void)check1024CRCWithLocath:(int)location
{
    
    int tempAbleLength =ableLength-6;
      tempAbleLength -=tempAbleLength%4;
      NSUInteger allCount = 4098/tempAbleLength+(4098%tempAbleLength==0?0:1)+1;
      [self.delegate MySourceProgress:((allCount*location)/(float)totalPackage)];
    
    NSMutableArray * arrayCRC = [[NSMutableArray alloc] init];
    NSArray * arrayData = arrayDetailTemp[location];
    NSMutableArray * tempArray = [NSMutableArray arrayWithArray:arrayData];
    if(tempArray.count==4096){
    for (int i = 0; i< 4; i++) {
        unsigned int c = 0;
        unsigned int TempCRC = 0xFFFF;
        for (int j = 0; j<1024; j++) {
            int temp = ((NSNumber*)tempArray[j+i*1024]).intValue;
            c = temp & 0x00FF;
            TempCRC^=c;
            for (int m=0; m<8; m++)
            {
                if (TempCRC & 0x0001)
                {
                    TempCRC >>= 1;
                    TempCRC ^= 0xA001;
                }
                else
                {
                    TempCRC >>= 1;
                }
            }
        }
        [arrayCRC addObject:@(TempCRC)];
    }
    uint8_t b[16];
    b[0] = 0x91;
    b[1] = location%256;
    b[2] = location/256;
    b[3] = 0xfe;
    NSNumber * numberTotalCRC = arrayBlockCRC[location];
    b[4] = numberTotalCRC.intValue % 256;
    b[5] = numberTotalCRC.intValue / 256;
    for (int i = 0 ; i <arrayCRC.count; i++) {
        NSNumber * numberCRC = arrayCRC[i];
        b[i*2+6] = numberCRC.intValue % 256;
        b[i*2+7] = numberCRC.intValue / 256;
    }

    unsigned int c = 0;
    unsigned int TempCRC = 0xFFFF;
    for (int j = 0; j<14; j++) {
        int temp = b[j];
        c = temp & 0x00FF;
        TempCRC^=c;
        for (int m=0; m<8; m++)
        {
            if (TempCRC & 0x0001)
            {
                TempCRC >>= 1;
                TempCRC ^= 0xA001;
            }
            else
            {
                TempCRC >>= 1;
            }
        }
    }
    b[14] = TempCRC%256;
    b[15] = TempCRC/256;
    NSMutableData *data = [[NSMutableData alloc] initWithBytes:b length:16];
    [[MyBle sharedManager] writeValueUI:ISSC_SERVICE_UUID characteristicUUID:ISSC_CHAR_TX_UUID p:[MyBle sharedManager].activePeripheral data:data];
    }
    else
        [self sendDataWithLocation:arrayBlockCRC.count-1];
    
}


// 需要升级发送数据
-(void)sendDataWithStartLocation:(int)location
{
  
    CurrentBlock = location;
    if(ableLength==0)
        ableLength = 133;
    NSArray * arrayData = arrayDetailTemp[location];
    NSMutableArray * tempArray = [NSMutableArray arrayWithArray:arrayData];
    [tempArray addObject:[NSNumber numberWithInt:((NSNumber*)arrayBlockCRC[location]).intValue%256]];
    [tempArray addObject:[NSNumber numberWithInt:((NSNumber*)arrayBlockCRC[location]).intValue/256]];
    NSLog(@"crc = %02x%02x",((NSNumber*)arrayBlockCRC[location]).intValue%256,((NSNumber*)arrayBlockCRC[location]).intValue/256);
    //每次最大发送的数据量
    int tempAbleLength =ableLength-6;
    tempAbleLength -=tempAbleLength%4;
    NSUInteger allCount = tempArray.count/tempAbleLength+(tempArray.count%tempAbleLength==0?0:1);
    for (int j=0; j<allCount; j++) {
        int sendCount = ((int)tempArray.count-j*tempAbleLength)>=tempAbleLength?tempAbleLength:((int)tempArray.count-j*tempAbleLength);
        int temp[sendCount];
        for (int m= 0; m<sendCount; m++)
            temp[m] = ((NSNumber*)tempArray[j*tempAbleLength+m]).intValue;
        
        if(arrayReceiveCRCCheck.count==arraySendCRCCheck.count&&arrayReceiveCRCCheck!=nil&&arrayReceiveCRCCheck.count!=0)
        {
            if(![arrayReceiveCRCCheck[j] isEqual:arraySendCRCCheck[j]])
            {
                [self sendDetailData1:temp length:sendCount block:location blockNumber:j];
            }
        }
        else
            [self sendDetailData:temp length:sendCount block:location blockNumber:j];
        NSLog(@"location%d",location);
        //发送一个结束标志
        if(j==allCount-1)
        {
            int endTemp[2];
            endTemp[0] = ((NSNumber*)arrayBlockCRC[location]).intValue%256;
            endTemp[1] = ((NSNumber*)arrayBlockCRC[location]).intValue/256;
            [self sendDetailData:endTemp length:2 block:location blockNumber:0xff];
            [self  getTotalPackage];
        }
    }
}
// temp :要发送的数据  length:发送数据的长度 block:块编号 blockNumber:块内部编号
-(void)sendDetailData:(int*)temp length:(int)length block:(int) block blockNumber:(int) blockNumber
{
     // 先计算已经发送的长度
    int tempAbleLength =ableLength-6;
    tempAbleLength -=tempAbleLength%4;
    NSUInteger allCount = 4098/tempAbleLength+(4098%tempAbleLength==0?0:1)+1;
    [self.delegate MySourceProgress:((allCount*block)/(float)totalPackage)];
    /*
    CurrentPackage +=1;
    labPackage.text = [NSString stringWithFormat:@"%d",CurrentPackage];
    labPercent.text = [NSString stringWithFormat:@"%.0f%%",CurrentPackage/(float)totalPackage*100];
     */
    uint8_t b[length+6];
    b[0] = 0x91;
    b[1] = block%256;
    b[2] = block/256;
    b[3] = blockNumber;
    for (int i =0; i<length; i++) {
        b[4+i]  = temp[i];
    }
    unsigned int c = 0;
    unsigned int TempCRC = 0xFFFF;
    for (int j = 0; j<length+4; j++) {
        int temp = b[j];
        c = temp & 0x00FF;
        TempCRC^=c;
        for (int m=0; m<8; m++)
        {
            if (TempCRC & 0x0001)
            {
                TempCRC >>= 1;
                TempCRC ^= 0xA001;
            }
            else
            {
                TempCRC >>= 1;
            }
        }
    }
    b[length+4] = TempCRC%256;
    b[length+5] = TempCRC/256;
    [arraySendCRCCheck addObject:[NSString stringWithFormat:@"%02x%02x", b[length+4], b[length+5]]];
    NSMutableData *data = [[NSMutableData alloc] initWithBytes:b length:length+6];
    NSLog(@"发送：%@",data);
    [[MyBle sharedManager] writeValueUI:ISSC_SERVICE_UUID characteristicUUID:ISSC_CHAR_TX_UUID p:[MyBle sharedManager].activePeripheral data:data];
    
}

-(void)sendDetailData1:(int*)temp length:(int)length block:(int) block blockNumber:(int) blockNumber
{
    //
   
    uint8_t b[length+6];
    b[0] = 0x91;
    b[1] = block%256;
    b[2] = block/256;
    b[3] = blockNumber;
    for (int i =0; i<length; i++) {
        b[4+i]  = temp[i];
    }
    unsigned int c = 0;
    unsigned int TempCRC = 0xFFFF;
    for (int j = 0; j<length+4; j++) {
        int temp = b[j];
        c = temp & 0x00FF;
        TempCRC^=c;
        for (int m=0; m<8; m++)
        {
            if (TempCRC & 0x0001)
            {
                TempCRC >>= 1;
                TempCRC ^= 0xA001;
            }
            else
            {
                TempCRC >>= 1;
            }
        }
    }
    b[length+4] = TempCRC%256;
    b[length+5] = TempCRC/256;
    if(blockNumber<arraySendCRCCheck.count)
    [arraySendCRCCheck replaceObjectAtIndex:blockNumber withObject:[NSString stringWithFormat:@"%02x%02x", b[length+4], b[length+5]]];
    NSMutableData *data = [[NSMutableData alloc] initWithBytes:b length:length+6];
    [[MyBle sharedManager] writeValueUI:ISSC_SERVICE_UUID characteristicUUID:ISSC_CHAR_TX_UUID p:[MyBle sharedManager].activePeripheral data:data];
}

-(void)sendDataWithLocation:(int)location
{
    if(arraySendCRCCheck==nil)
        arraySendCRCCheck = [[NSMutableArray alloc] init];
    [arraySendCRCCheck removeAllObjects];
    [self sendDataWithStartLocation:location];
}


-(void)sendLastData
{
    int endTemp[2];
    endTemp[0] = ((NSNumber*)arrayBlockCRC[CurrentBlock]).intValue%256;
    endTemp[1] = ((NSNumber*)arrayBlockCRC[CurrentBlock]).intValue/256;
    
    [self sendDetailData1:endTemp length:2 block:CurrentBlock blockNumber:0xff];
}

-(void)CleadData
{
    /*
    [arrayReceiveCRCCheck removeAllObjects];
    [arraySendCRCCheck removeAllObjects];
     */
}

//擦除资源文件
-(void)EraseResourceFiles
{
      uint8_t  b[5]={0x90,0x70,0,0,0};
        unsigned int c = 0;
        unsigned int TempCRC = 0xFFFF;
        for (int j = 0; j<3; j++) {
            int temp = b[j];
            c = temp & 0x00FF;
            TempCRC^=c;
            for (int m=0; m<8; m++)
            {
                if (TempCRC & 0x0001)
                {
                    TempCRC >>= 1;
                    TempCRC ^= 0xA001;
                }
                else
                {
                    TempCRC >>= 1;
                }
            }
        }
        b[3] = TempCRC%256;
        b[4] = TempCRC/256;
        NSMutableData *data = [[NSMutableData alloc] initWithBytes:b length:5];
         [[MyBle sharedManager] writeValue:ISSC_SERVICE_UUID characteristicUUID:ISSC_CHAR_TX_UUID p:[MyBle sharedManager].activePeripheral data:data];
}

@end
